var app;
var map;
require(["esri/Color",
  "dojo/string",
  "dijit/registry",  
  "esri/config",
  "esri/map",
  "esri/layers/ArcGISDynamicMapServiceLayer",
  "esri/graphic",
  "esri/tasks/Geoprocessor",
  "esri/tasks/FeatureSet",
  "esri/toolbars/draw",
  "esri/symbols/SimpleLineSymbol",
  "esri/symbols/SimpleFillSymbol",
  "esri/layers/FeatureLayer",
  "dojo/parser",
  "dojo/ready",
  "dijit/layout/BorderContainer",
  "dijit/layout/ContentPane",
  "dojo/dom",
  "dojo/on",
  "dojo/query",
  "esri/urlUtils",
  "esri/arcgis/utils",
  "esri/dijit/Legend",
  "esri/dijit/Scalebar",  
  "esri/layers/ImageParameters",
  "esri/tasks/query",
  "esri/geometry/Circle",
  "esri/InfoTemplate",
  "esri/symbols/SimpleMarkerSymbol",
  "esri/renderers/SimpleRenderer",
  "dojo/domReady!"
   
  ], 
  function(Color, string, registry, esriConfig, Map, ArcGISDynamicMapServiceLayer, Graphic, Geoprocessor, FeatureSet, Draw, SimpleLineSymbol, SimpleFillSymbol,FeatureLayer,
    parser,ready,BorderContainer,ContentPane,dom,on,query,urlUtils,arcgisUtils,Legend,Scalebar,ImageParameters,Query, Circle, InfoTemplate, SimpleMarkerSymbol, SimpleRenderer){
   
    
 
  var map, gp, toolbar; 
  app = {
        "map": map,
        "toolbar": toolbar
      }; 
       
       //esriConfig.defaults.io.proxyUrl = "/proxy";
        
  app.map = map =  new Map("mapDiv",{
    basemap:"topo",
    center:[-100.1,39.1],
    zoom:4
  });
   
    
 
   map.on("load", initTools);
    
  var layerURL_Olive = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/0";
  var layerURL_Logger = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/1";
  var layerURL_Leather = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/2";
  var layerURL_Kemp = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/3";
  var layerURL_Hawks = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/4";
  var layerURL_Green = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/5";
  var layerURL_GreenRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/6";
  var layerURL_HawksRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/7";
  var layerURL_KempsRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/8";
  var layerURL_LeatherRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/9";
  var layerURL_LoggerRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/10";
  var layerURL_OliveRange = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/11";
  var layerURL_KempsHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/12";
  var layerURL_HawksHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/13";
  var layerURL_LeatherHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/14";
  var layerURL_LoggerHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/15";
  var layerURL_OliveHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/16";
  var layerURL_GreenHabitat = "https://services7.arcgis.com/ChfoxIueFCplIHdF/ArcGIS/rest/services/TurtleUS/FeatureServer/17";
  var featureLayer_Olive = new FeatureLayer(layerURL_Olive, {
              infoTemplate: new InfoTemplate("Attributes","Id:${ID} in Olive Nests"),
              outFields: ["*"]
          });
  var featureLayer_Logger = new FeatureLayer(layerURL_Logger, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Logger Nests"),
              outFields: ["*"]
          }); 
  var featureLayer_Leather = new FeatureLayer(layerURL_Leather, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Leather Nests"),
              outFields: ["*"]
          });
  var featureLayer_Kemp = new FeatureLayer(layerURL_Kemp, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Kemp Nests"),
              outFields: ["*"]
          }); 
  var featureLayer_Hawks = new FeatureLayer(layerURL_Hawks, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Hawks Nests"),
              outFields: ["*"]
          });
  var featureLayer_Green = new FeatureLayer(layerURL_Green, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Green Nests"),
              outFields: ["*"]
          });
           
     var featureLayer_GreenRange = new FeatureLayer(layerURL_GreenRange, {
              infoTemplate: new InfoTemplate("Attributes","Id:${ID} in Greens Range"),
              outFields: ["*"]
          });
  var featureLayer_HawksRange = new FeatureLayer(layerURL_HawksRange, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Hawks Range"),
              outFields: ["*"]
          }); 
  var featureLayer_KempsRange = new FeatureLayer(layerURL_KempsRange, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Kemps Range"),
              outFields: ["*"]
          });
  var featureLayer_LeatherRange = new FeatureLayer(layerURL_LeatherRange, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Leather Range"),
              outFields: ["*"]
          }); 
  var featureLayer_LoggerRange = new FeatureLayer(layerURL_LoggerRange, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Logger Range"),
              outFields: ["*"]
          });
  var featureLayer_OliveRange = new FeatureLayer(layerURL_OliveRange, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Green Range"),
              outFields: ["*"]
          });
          
          var featureLayer_KempsHabitat = new FeatureLayer(layerURL_KempsHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id:${ID} in Kemps Habitat"),
              outFields: ["*"]
          });
  var featureLayer_HawksHabitat = new FeatureLayer(layerURL_HawksHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Hawks Habitat"),
              outFields: ["*"]
          }); 
  var featureLayer_LeatherbackHabitat = new FeatureLayer(layerURL_LeatherHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Leatherback Habitat"),
              outFields: ["*"]
          });
  var featureLayer_LoggerheadHabitat = new FeatureLayer(layerURL_LoggerHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in  Logger Habitat"),
              outFields: ["*"]
          }); 
  var featureLayer_OliveHabitat = new FeatureLayer(layerURL_OliveHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Olive Habitat"),
              outFields: ["*"]
          });
  var featureLayer_GreenHabitat = new FeatureLayer(layerURL_GreenHabitat, {
              infoTemplate: new InfoTemplate("Attributes","Id: ${ID} in Green Habitat"),
              outFields: ["*"]
          });
                  
    
  map.addLayers([featureLayer_Olive,featureLayer_Logger,featureLayer_Leather,featureLayer_Kemp, featureLayer_Hawks, featureLayer_Green, featureLayer_GreenRange, featureLayer_HawksRange, featureLayer_KempsRange, featureLayer_LeatherRange,featureLayer_LoggerRange, featureLayer_OliveRange, featureLayer_KempsHabitat, featureLayer_HawksHabitat, featureLayer_LeatherbackHabitat, featureLayer_LoggerheadHabitat, featureLayer_OliveHabitat, featureLayer_GreenHabitat]);  
     
  
           
 
 
  var populationMap = new ArcGISDynamicMapServiceLayer("https://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Demographics/ESRI_Population_World/MapServer");
  populationMap.setOpacity(0.5);
  map.addLayer(populationMap);
 
  //identify proxy page to use if the toJson payload to the geoprocessing service is greater than 2000 characters.
  //If this null or not available the gp.execute operation will not work.  Otherwise it will do a http post to the proxy.
  esriConfig.defaults.io.proxyUrl = "/proxy/";
  esriConfig.defaults.io.alwaysUseProxy = false;
 
  function initTools(evtObj) {
    gp = new Geoprocessor("https://sampleserver1.arcgisonline.com/ArcGIS/rest/services/Demographics/ESRI_Population_World/GPServer/PopulationSummary");
    gp.setOutputSpatialReference({wkid:102100}); 
    gp.on("execute-complete", displayResults);
 
    app.toolbar = toolbar = new Draw(evtObj.map);
    toolbar.on("draw-end", computeZonalStats);
  }
 
  function computeZonalStats(evtObj) {
    var geometry = evtObj.geometry;
    /*After user draws shape on map using the draw toolbar compute the zonal*/
    map.showZoomSlider();
    map.graphics.clear();
     
    var symbol = new SimpleFillSymbol("none", new SimpleLineSymbol("dashdot", new Color([255,0,0]), 2), new Color([255,255,0,0.25]));
    var graphic = new Graphic(geometry,symbol);
 
    map.graphics.add(graphic);
    toolbar.deactivate();
 
    var features= [];
    features.push(graphic);
 
    var featureSet = new FeatureSet();
    featureSet.features = features;
     
    var params = { "inputPoly":featureSet };
    gp.execute(params);
  }
 
  function displayResults(evtObj) {
    var results = evtObj.results;
    var content = string.substitute("<h4>The population in the user defined polygon is ${number:dojo.number.format}.</h4>",{number:results[0].value.features[0].attributes.SUM});
 
    registry.byId("dialog1").setContent(content);
    registry.byId("dialog1").show();
  }
   
  ready(function(){
       
    parser.parse();      
    arcgisUtils.createMap("ef2757bb95034187b4c1eee459fbeedf","mapDiv").then(function(response){
       
      dom.byId("title").innerHTML = response.itemInfo.item.title;
      dom.byId("subtitle").innerHTML = response.itemInfo.item.snippet;
 
      var map = response.map;
 
 var legend = new Legend({
    map: map,
    layerInfos:(arcgisUtils.getLegendLayers(response))
  }, "legendDiv");
       
  legend.startup();
});
 
      
     
 
      //add the legend. Note that we use the utility method getLegendLayers to get
      //the layers to display in the legend from the createMap response.
      var legendLayers = arcgisUtils.getLegendLayers(response);
      var legendDijit = new Legend({
        map: map,
        layerInfos: legendLayers
      },"legend");
      legendDijit.startup();
 
 
    
 
 
    });
 
 
 
});